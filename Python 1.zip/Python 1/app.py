from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def main():
    return render_template("Main.html")


@app.route('/Product')
def product():
    return render_template("Product.html ")


@app.route('/Cart')
def cart():
    return render_template("Cart.html")


@app.route('/User')
def user():
    return render_template("User.html")


if __name__ == '__main__':
    app.run(debug=True)
